/*
-----------------------------------------------------------------------------
This source file is part of OGRE
    (Object-oriented Graphics Rendering Engine)
For the latest info, see http://www.ogre3d.org/

Copyright � 2000-2002 The OGRE Team
Also see acknowledgements in Readme.html

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA, or go to
http://www.gnu.org/copyleft/lesser.txt.
-----------------------------------------------------------------------------
*/
#ifndef _Resource_H__
#define _Resource_H__

#include "OgrePrerequisites.h"

#include "OgreString.h"

namespace Ogre {

    typedef unsigned long ResourceHandle;

    /** Abstract class reprensenting a loadable resource (e.g. textures, sounds etc)
        @remarks
            Resources are generally passive constructs, handled through the
            ResourceManager abstract class for the appropriate subclass.
            The main thing is that Resources can be loaded or unloaded by the
            ResourceManager to stay within a defined memory budget. Therefore,
            all Resources must be able to load, unload (whilst retainin enough
            info about themselves to be reloaded later), and state how big
            they are.
        @par
            Subclasses must implement:
                1. A constructor, with at least a mandatory name param.
                This constructor must set mName and optionally mSize.
                2. The load() and unload() methods - mSize must be set after load()
                Each must check & update the mIsLoaded flag.
    */
    class _OgreExport Resource 
    {
        friend class ResourceManager;
    protected:
        String mName;
        ResourceHandle mHandle;
        bool   mIsLoaded;
        time_t mLastAccess;
        size_t mSize;

    public:
        /** Basic constructor. 
            @warn
                Subclasses must init mName, mHandle and mSize!
        */
        Resource() 
            : mIsLoaded( false ), mSize( 0 )
        { 
        }

        /** Virtual destructor. Shouldn't need to be overloaded, as the resource
            deallocation code should reside in unload()
            @see
                Resource::unload()
        */
        virtual ~Resource() 
        { 
            if( mIsLoaded )
                unload(); 
        }

        /** Loads the resource, if it is not already.
        */
        virtual void load() = 0;

        /** Unloads the resource, but retains data to recreate.
        */
        virtual void unload() {};

        /** Retrieves info about the size of the resource.
        */
        virtual size_t getSize(void) const
        { 
            return mSize; 
        }

        /** 'Touches' the resource to indicate it has been used.
        */
        virtual void touch(void) 
        { 
            mLastAccess = time(NULL); 
            if (!mIsLoaded) load();
        }

        /** Gets the last time the resource was 'touched'.
        */
        time_t getLastAccess(void) const 
        { 
            return mLastAccess; 
        }

        /** Gets resource name.
        */
        const String& getName(void) const 
        { 
            return mName; 
        }

        ResourceHandle getHandle(void) const
        {
            return mHandle;
        }

        /** Returns true if the Resource has been loaded, false otherwise.
        */
        bool isLoaded(void) const 
        { 
            return mIsLoaded; 
        }

        /** A method to make the resource delete itself.
            @note
                This exists because Resource objects could be created in other processes,
                and they need to be destroyed in the process that created them.
        */
        virtual void destroy()
        {
            delete this;
        }
    };

}

#endif
